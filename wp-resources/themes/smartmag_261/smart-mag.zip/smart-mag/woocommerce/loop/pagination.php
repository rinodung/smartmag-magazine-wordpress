<?php 
/**
 * Pagination - Show numbered pagination for catalog pages.
 * 
 * @version     2.2.2
 */
?>
	<div class="main-pagination">
		<?php echo Bunyad::posts()->paginate(); ?>
	</div>